"""
Central configuration for the Voice-Based Medicine Prescription Entry System.

Every environment-specific value (file paths, model name, CORS origins, etc.)
lives here so the rest of the codebase never hard-codes it. Values can be
overridden with environment variables (see .env.example).
"""

import os
from pathlib import Path

# ---------------------------------------------------------------------------
# Base paths
# ---------------------------------------------------------------------------
BACKEND_DIR = Path(__file__).resolve().parent

# ---------------------------------------------------------------------------
# Medicine CSV configuration
# ---------------------------------------------------------------------------
# Change this path (or set MEDICINE_CSV_PATH env var) once the organization
# provides the real medicine.csv file.
MEDICINE_CSV_PATH = Path(
    os.getenv("MEDICINE_CSV_PATH", str(BACKEND_DIR / "data" / "medicine.csv"))
)

# Candidate column names the loader will look for (case-insensitive).
# The first match found in the CSV is used for each field. This lets the
# same code work whether the CSV has "Medicine Name", "item_name",
# "MedicineName", etc.
MEDICINE_NAME_COLUMNS = ["medicine name", "medicine_name", "item_name", "name", "medicine"]
GENERIC_NAME_COLUMNS = ["generic name", "generic_name", "generic"]
STRENGTH_COLUMNS = ["strength", "dosage", "power"]
FORM_COLUMNS = ["form", "dosage form", "type"]

# ---------------------------------------------------------------------------
# Whisper (local, offline) configuration
# ---------------------------------------------------------------------------
# Name of the whisper model to load (tiny, base, small, medium, large, ...)
WHISPER_MODEL_NAME = os.getenv("WHISPER_MODEL_NAME", "base")

# Local directory that must contain the pre-downloaded model weights
# (e.g. backend/models/whisper/base.pt). The backend NEVER downloads the
# model automatically — it must already exist here.
WHISPER_MODEL_PATH = Path(
    os.getenv("WHISPER_MODEL_PATH", str(BACKEND_DIR / "models" / "whisper"))
)

# Force CPU inference (no GPU required).
WHISPER_DEVICE = os.getenv("WHISPER_DEVICE", "cpu")

# Language hint for transcription. Set to None to let Whisper auto-detect.
WHISPER_LANGUAGE = os.getenv("WHISPER_LANGUAGE", "en")

# ---------------------------------------------------------------------------
# Fuzzy matching configuration
# ---------------------------------------------------------------------------
# Minimum similarity score (0-100) for a medicine to be shown as a match.
MATCH_MIN_SCORE = int(os.getenv("MATCH_MIN_SCORE", "60"))

# Maximum number of matches returned per search.
MATCH_MAX_RESULTS = int(os.getenv("MATCH_MAX_RESULTS", "10"))

# ---------------------------------------------------------------------------
# CORS / server configuration
# ---------------------------------------------------------------------------
ALLOWED_ORIGINS = os.getenv("ALLOWED_ORIGINS", "*").split(",")
HOST = os.getenv("HOST", "0.0.0.0")
PORT = int(os.getenv("PORT", "8000"))

# ---------------------------------------------------------------------------
# Audio handling
# ---------------------------------------------------------------------------
TEMP_AUDIO_DIR = Path(os.getenv("TEMP_AUDIO_DIR", str(BACKEND_DIR / "temp_audio")))
TEMP_AUDIO_DIR.mkdir(parents=True, exist_ok=True)
